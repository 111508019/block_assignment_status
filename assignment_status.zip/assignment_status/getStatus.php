<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details
 *
 * @package    block
 * @subpackage block_assignment_status
 * @copyright  Vaishnavi Chidrawar
 * @copyright  Sneha Chhajed
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('../../config.php');

global $OUTPUT, $DB, $CFG, $USER, $PAGE;
$courseid = optional_param('id', SITEID, PARAM_INT);
$courseName = $_GET['courseName'];
$SITE = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
$url = new moodle_url($CFG->wwwroot . '/blocks/assignment_status/getStatus.php', array('id' => $course->id, 'courseName' => $course->fullname));
require_login($SITE, false, $cm);
$context = context_course::instance($courseid);
$PAGE->set_url($url);
$PAGE->set_heading($courseName);
$PAGE->set_context($context);
echo $OUTPUT->header();
$PAGE->set_pagelayout('standard');
	$cid = $_GET['id'];
	$user1 = $USER->id;
	$submitted = "SELECT name, a.id from {assign} a JOIN {assign_submission} sub ON (a.id = sub.assignment AND userid = $user1) where a.course = $cid AND sub.status = 'submitted' AND a.id not in(select g.assignment from {assign_grades} g where userid = $user1 )";
	$not_submitted = "SELECT name, a.id from {assign} a where  a.course = $cid AND a.id not in(select sub.assignment from {assign_submission} sub where userid = $user1 and status = 'submitted')"; 
	$graded = "SELECT name, a.id from {assign} a where a.course = $cid AND a.id in(select g.assignment from {assign_grades} g where userid = $user1)";
	/*$assignment_link = "SELECT m.id from {course_modules} m JOIN {assign} a ON (a.id = m.instance) where m.course = $cid and m.module = 1";*/
	$assignment_link_submitted = "SELECT m.id from {course_modules} m where m.course = $cid AND m.module = 1 AND m.instance in (SELECT a.id from {assign} a JOIN {assign_submission} sub ON (a.id = sub.assignment AND userid = $user1) where a.course = $cid AND sub.status = 'submitted' AND a.id not in(select g.assignment from {assign_grades} g where userid = $user1 ))";
	$assignment_link_not_submitted = "SELECT m.id from {course_modules} m where m.course = $cid AND m.module = 1 AND m.instance in (SELECT a.id from {assign} a where  a.course = $cid AND a.id not in(select sub.assignment from {assign_submission} sub where userid = $user1 and status = 'submitted'))";
	$assignment_link_graded = "SELECT m.id from {course_modules} m where m.course = $cid AND m.module = 1 AND m.instance in (SELECT a.id from {assign} a where a.course = $cid AND a.id in(select g.assignment from {assign_grades} g where userid = $user1))";  
	$assignments_submitted = $DB->get_records_sql($submitted);
	$assignments_not_submitted = $DB->get_records_sql($not_submitted);
	$assignments_graded = $DB->get_records_sql($graded);
	$assignments_link_submitted = $DB->get_records_sql($assignment_link_submitted);
	$assignments_link_not_submitted = $DB->get_records_sql($assignment_link_not_submitted);
	$assignments_link_graded = $DB->get_records_sql($assignment_link_graded);
	$i = 0;
	foreach ($assignments_link_submitted as $records) {
		$links[$i] = $records->id;
		$i++;	
	}
	foreach ($assignments_link_not_submitted as $records) {
		$links[$i] = $records->id;
		$i++;	
	}
	foreach ($assignments_link_graded as $records) {
		$links[$i] = $records->id;
		$i++;	
	}
	$i = 0;
	$html = '';
	$html .= html_writer::start_tag('div', array('id' => 'assignment_section'));
	$html .= html_writer::start_tag('table', array('id' => 'assignment_table', 'class' => 'generaltable assignment_table'));
	$html .= html_writer::start_tag('tr');
	$html .= html_writer::start_tag('th', array('id' => 'td', 'class' => 'td'));
	$html .= html_writer::start_tag('b');
	$html .= "Assignments";
	$html .= html_writer::end_tag('b');
	$html .= html_writer::end_tag('th');
	$html .= html_writer::start_tag('th', array('id' => 'td2', 'class' => 'td2'));
	$html .= html_writer::start_tag('b');
	$html .= "Status";
	$html .= html_writer::end_tag('b');
	$html .= html_writer::end_tag('th');
	$html .= html_writer::end_tag('tr');
	foreach ($assignments_submitted as $records) {
		$html .= html_writer::start_tag('tr');
		$html .= html_writer::start_tag('td', array('id' => 'td', 'class' => 'td'));
		$html .= html_writer::start_tag('a', array('href' => '/moodle/mod/assign/view.php?id='.$links[$i]));
		$html .= $records->name;
		$html .= html_writer::end_tag('a');
		$html .= html_writer::end_tag('td');
		$html .= html_writer::start_tag('td', array('id' => 'td2', 'class' => 'td2'));
		$html .= "Submitted";
		$html .= html_writer::end_tag('td');
		$html .= html_writer::end_tag('tr');
		$i++;
	}
	foreach ($assignments_not_submitted as $records) {
		$html .= html_writer::start_tag('tr');
		$html .= html_writer::start_tag('td', array('id' => 'td', 'class' => 'td'));
		$html .= html_writer::start_tag('a', array('href' => '/moodle/mod/assign/view.php?id='.$links[$i]));
		$html .= $records->name;
		$html .= html_writer::end_tag('a');
		$html .= html_writer::end_tag('td');
		$html .= html_writer::start_tag('td', array('id' => 'td2', 'class' => 'td2'));
		$html .= "Not submitted";
		$html .= html_writer::end_tag('td');
		$html .= html_writer::end_tag('tr');
		$i++;
	}
	foreach ($assignments_graded as $records) {
		$html .= html_writer::start_tag('tr');
		$html .= html_writer::start_tag('td', array('id' => 'td', 'class' => 'td'));
		$html .= html_writer::start_tag('a', array('href' => '/moodle/mod/assign/view.php?id='.$links[$i]));
		$html .= $records->name;
		$html .= html_writer::end_tag('a');
		$html .= html_writer::end_tag('td');
		$html .= html_writer::start_tag('td', array('id' => 'td2', 'class' => 'td2'));
		$html .= "Graded";
		$html .= html_writer::end_tag('td');
		$html .= html_writer::end_tag('tr');
		$i++;
	}
	$html .= html_writer::end_tag('table');
	$html .= html_writer::end_tag('div');
	//echo html_writer::table($table);
	echo $html;
	echo $OUTPUT->footer();
?>
